import sys
from PyQt5 import QtWidgets
from window2 import *
from parser_site import parse_olimp
from window4 import Ui_Dialog
from window5 import Ui_MainWindow3
from search_db import *
from window6 import Ui_MainWindow5
from window7 import *


class Search1(QtWidgets.QMainWindow):
    def __init__(self):
        super(Search1, self).__init__()
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        self.check_db = CheckThread()
        self.base_line_edit1 = self.ui.lineEdit_search1

        self.subject_search_combo_box()
        self.class_search_combo_box()
        self.type_search_combo_box()
        self.pushButton_search_Button()

    def subject_search_combo_box(self):
        subject_search = ([
            'Биология', 'География', 'Информатика', 'Математика', 'Физика', 'Химия', 'Астрономия', 'ИЗО', 'Искусство',
            'История', 'Лингвистика', 'Литература', 'ОБЖ', 'Обществознание', 'Предпринимательсво', 'Право',
            'Психология', 'Робототехника', 'Русский язык', 'Технология', 'Физкультура', 'Черчение', 'Экология',
            'Экономика', 'Ин.языки'
        ])
        self.ui.subject_search.addItems(subject_search)

    def class_search_combo_box(self):
        class_search = ([])
        for item in range(11):
            class_search.append(str(item + 1))
        self.ui.class_search.addItems(class_search)

    def type_search_combo_box(self):
        type_search = ([
            'Командные', 'Личные', 'Дистанционные', 'Все'
        ])
        self.ui.type_search.addItems(type_search)

    def pushButton_search_Button(self):
        self.ui.pushButton_search1.clicked.connect(self.pushButton_search_clicked1)
        self.ui.pushButton_search2.clicked.connect(self.reg)
        self.ui.pushButton_search3.clicked.connect(self.pushButton_search_clicked5)
        self.ui.pushButton_search4.clicked.connect(self.pushButton_search_clicked4)

    def pushButton_search_clicked1(self):
        text1 = self.ui.subject_search.currentText()
        text2 = self.ui.class_search.currentText()
        text3 = self.ui.type_search.currentText()
        text = parse_olimp.parse_text(text1, text2, text3)
        self.ui.textEdit.setText(f'{text}')

    def pushButton_search_clicked4(self):
        self.window3 = QtWidgets.QMainWindow()
        self.ui = Ui_MainWindow3()
        self.ui.setupUi(self.window3)
        self.window3.show()
        self.ui.pushButton1.clicked.connect(self.open_window1)

    def pushButton_search_clicked5(self):
        self.window5 = QtWidgets.QMainWindow()
        self.ui = Ui_MainWindow5()
        self.ui.setupUi(self.window5)
        self.window5.show()
        self.ui.pushButton_search6.clicked.connect(self.auth)
        self.ui.pushButton_search5.clicked.connect(self.close_window5)

    def close_window5(self):
        self.window5.close()

    def open_window1(self):
        self.window2 = QtWidgets.QDialog()
        self.ui = Ui_Dialog()
        self.ui.setupUi(self.window2)
        self.window2.show()
        self.ui.pushButton_1.clicked.connect(self.on_accepted)
        self.ui.pushButton_2.clicked.connect(self.off_accepted)

    def off_accepted(self):
        self.window2.close()

    def on_accepted(self):
        self.window2.close()

    def auth(self):
        print(2)
        name = self.ui.lineEdit_search1.text()
        self.check_db.thr_login(name)

    def reg(self):
        print(1)
        self.ui.lineEdit_search1.clear()
        name = self.ui.lineEdit_search1.text()
        self.check_db.thr_register(name)

    def open_window2(self):
        self.window4 = QtWidgets.QDialog()
        self.ui = Ui_Form2()
        self.ui.setupUi(self.window4)
        self.window4.show()


if __name__ == '__main__':
    app = QtWidgets.QApplication(sys.argv)
    sear = Search1()
    sear.show()
    sys.exit(app.exec_())
