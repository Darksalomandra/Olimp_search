from PyQt5 import QtCore, QtGui, QtWidgets
from handler.work_db import *


class CheckThread(QtCore.QThread):
    mysignal = QtCore.pyqtSignal(str)

    def thr_login(self, name):
        login(name, self.mysignal)

    def thr_register(self, name):
        register(name, self.mysignal)
