import sqlite3
from all.main import Search1


def bd_see():
    con = sqlite3.connect("db_olimp.sqlite")
    cur = con.cursor()
    result = cur.execute("""SELECT * FROM db_search""").fetchall()
    for elem in result:
        print(elem)
    con.close()


def bd_sive(text_value):
    con = sqlite3.connect("db_olimp.sqlite")
    cur = con.cursor()
    result = cur.execute(f"""INSERT INTO db_search(name_search) VALUES({text_value})""").fetchall()
    for elem in result:
        print(elem)
    con.close()


def bd_delete(text_value):
    con = sqlite3.connect("handler/db_site.sqlite")
    cur = con.cursor()
    result = cur.execute(f"""DELETE from db_search
        where name_search = {text_value}""").fetchall()
    for elem in result:
        print(elem)
    con.close()


def login(login, signal):
    con = sqlite3.connect('handler/db_site.sqlite')
    cur = con.cursor()

    cur.execute(f'SELECT * FROM bd_search WHERE name_search="{login}";')
    value = cur.fetchall()
    if not value:
        signal.emit('Проверьте правильность ввода данных!')

    cur.close()
    con.close()


def register(login, signal):
    con = sqlite3.connect('handler/db_site.sqlite')
    cur = con.cursor()

    cur.execute(f'SELECT * FROM db_search WHERE name_search="{login}";')
    value = cur.fetchall()
    if value:
        signal.emit('Такая олимпиада уже используется!')
    elif not value:
        cur.execute(f"INSERT INTO db_search (name_search) VALUES ('{login}')")
        signal.emit('Вы успешно сохранили олимпиаду!')
        con.commit()

    cur.close()
    con.close()
